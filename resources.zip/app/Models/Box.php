<?php
/**
 * Created by PhpStorm.
 * User: Yerman
 * Date: 17.08.2017
 * Time: 12:26
 */


namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Box extends Model
{
    protected $fillable = [
        'sum'
    ];
}
<?php
/**
 * Created by PhpStorm.
 * User: Yerman
 * Date: 17.08.2017
 * Time: 12:22
 */

namespace App\Http\Controllers;


use App\Models\Box;

class BoxesController extends Controller
{
    public function index()
    {
        return view('vue', [

        ]);
    }
}